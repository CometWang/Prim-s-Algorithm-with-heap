
//Jia Wang 251041197
#include <iostream>
using namespace std;


struct heapNode{
    //represent nodes in the heap
    int id;//index
    int nodeKey;//weight
    //int col;//for adj list
    //int row;

};

class heap{

public:
    //features of the heap
    int size; //current size
    int capacity; //capacity of the heap
    struct heapNode ** nodeArray;
    int* mrp; // for the decrease key
    //struct heapNode* newNode(int id, int nodeKey);


    //create new heap node
    struct heapNode* newNode(int id, int nodeKey){
       struct heapNode* newheapNode = (struct heapNode*) malloc(sizeof(struct heapNode));
       newheapNode->id = id;
       newheapNode->nodeKey = nodeKey;
       return newheapNode;
    }


    //initialize the heap with mapping the vertec to an index so the lookupon time will be O(1)
    heap(int *keys, int n){
        size = 0;
        capacity = n;
        nodeArray = (heapNode **)malloc(sizeof(heapNode *) *n);//there are n nodes in the heap
        for(int i = 0; i<n; i++){
            mrp[keys[i]] = i; //map vertex to array index
        }

    }

    bool in_heap(int id){
        if(id>0 && mrp[id] < size){
            return true;
        }
        return false;
    }
    void insertNode(int id, heapNode* node){
        this->nodeArray[id] = node;
        this->size++;

    }
    void swapNode(heapNode **x, heapNode **y){
       heapNode *temp = *x;
       *x = *y;
       *y = temp;
    }

    void heapify(int id){
        int min, left, right;
        left = (2*id+1);
        right = (2*id+2);
        min = id;

        if (right < size && nodeArray[right]->nodeKey < nodeArray[min]->nodeKey)
            min = right;
        if (left < size && nodeArray[left]->nodeKey < nodeArray[min]->nodeKey)
            min = left;
        if (min != id){
            // To nodes to be swapped in min heap
            heapNode *minNode = nodeArray[min];
            heapNode *idNode = nodeArray[id];

            // Change the mapping
            this->mrp[minNode->id] = id;
            this->mrp[idNode->id] = min;

            // Swap Nodes using swapNode
            heap::swapNode(&minNode, &idNode);
            heapify(min);//heapify on the changed node again
        }
        return;
    }

    int min_key(){
        return this->nodeArray[0]->nodeKey;
    }
    int min_id(){
        return this->nodeArray[0]->id;
    }

    int key(int id){
        int index= mrp[id];
        return this->nodeArray[index]->nodeKey;
    }
    //void printheapArr()

    heapNode* delete_min(){
        if (size == 0){
            return NULL;
        }
        heapNode* root = this->nodeArray[0];
        //replace root node with the last one
        heapNode* last = this->nodeArray[size-1];
        this->nodeArray[0] = last;

        //change the map
        this->mrp[root->id] = this->size-1;
        this->mrp[last->nodeKey] = 0;

        this->size--;
        heap::heapify(0);
        return root;

    }
    void decrease_key(int id, int new_key){
        int index = this->mrp[id];
        //find the node to update its key
        this->nodeArray[index]->nodeKey = new_key;

        //swap the node and also update the map for the whole tree
        while (index && this->nodeArray[index]->nodeKey < this->nodeArray[(index-1)/2]->nodeKey){

            this->mrp[nodeArray[index]->id] = (index-1)/2;
            this->mrp[nodeArray[(index-1)/2]->id] = (index-1)/2;

            //swap the nodes
            heap::swapNode(&nodeArray[index], &nodeArray[(index-1)/2]);
            //decrease the index
            index = (index-1)/2;
        }
    }

};