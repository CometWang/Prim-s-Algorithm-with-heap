#include <iostream>
#include <vector>

using namespace std;

//each node in the list
struct adjnode{
    int sec;
    int weight;
    struct adjnode* next;
};

//nodes forming the list
class adjlist{
    struct adjlist* head;


    //function for new node in the list
    struct adjnode* createnewnode(int newsec, int newweight) {
        struct adjnode *newnode = (struct adjnode *) malloc(sizeof(adjnode));
        newnode->sec = newsec;
        newnode->weight = newweight;
        newnode->next = NULL;

        return newnode;

    }

};