//Jia Wang 251041197

#include "heap.h"
#include "adjList.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string.h>
#include <sstream>
#include <limits>
using namespace std;

//graph object
class graph{

public:
    int vertexamount;
    struct adjlist* arr;//form a graph

    //create new graph
    struct graph* newgraph(int amount){
        struct graph* ngraph = (struct graph*)malloc(sizeof(struct graph));
        ngraph->vertexamount = amount;
        ngraph->arr = (struct adjlist*)malloc(sizeof(struct adjlist));
        return ngraph;
    }


};

int main(){
    //read file
    ifstream infile;
    //infile.open("/Users/apple/CLionProjects/3340_3/infile", ios::binary | ios::in);
    infile.open("infile", ios::binary | ios::in);
    if(!infile){
        cout<< "can't open the file";
        exit(1);

    }
    string line;
    getline(infile, line);
    int amount = stoi(line);
    //printf("%d", amount);

    vector<int> adj[amount];
    cout<<"****************AdjList format of input file****************"<<endl;

    while(getline(infile, line)){

        istringstream newline;
        newline.str(line);

        //cout<<newline.str()<<endl;
        int first, second, distance;
        newline>>first;
        newline>>second;
        newline>>distance;

        cout<<"AdjList of vertex " << first << " -> vertex " << second << " -> " <<distance <<endl;


        continue;


    }



}